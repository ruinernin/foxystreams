import maincode
if __name__ == '__main__':
    maincode.run(*sys.argv[:3])
