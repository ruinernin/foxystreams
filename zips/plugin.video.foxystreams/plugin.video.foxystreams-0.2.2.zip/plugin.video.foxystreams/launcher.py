import addon
import sys
if __name__ == '__main__':
    addon.run(*sys.argv[:3])
